# Data Erasure Process: Migration from On-Premises to AWS

## Overview

This document outlines the migration plan for the **Data Erasure Process** from an on-premises Hadoop environment to AWS cloud infrastructure. The migration follows the established pattern used by the HEMS P10 ingestion workflow, leveraging Apache Airflow for orchestration and AWS EMR Serverless for compute execution.

The data erasure process is critical for GDPR compliance, allowing selective deletion of personal data across multiple data stores based on person keys. The AWS migration maintains the same core erasure logic while modernizing the infrastructure for better scalability, reliability, and cost efficiency.

## Migration Objectives

### Primary Goals
- **Infrastructure Modernization**: Migrate from YARN/HDFS to EMR Serverless/S3
- **Process Reliability**: Improve fault tolerance and monitoring capabilities
- **Compliance Continuity**: Maintain GDPR erasure capabilities without service interruption
- **Operational Efficiency**: Reduce manual intervention and improve observability
- **Cost Optimization**: Utilize serverless compute for on-demand processing

### Success Criteria
- Identical erasure logic and data processing outcomes
- Improved process monitoring and alerting
- Reduced operational overhead
- Enhanced audit trail and compliance reporting

## End-to-End Process Flow

### Current On-Premises Architecture

```bash
# Simplified flow representation
Manual Trigger → Shell Script → Lock File Check → Spark Jobs → HDFS Operations → Email Notification

# Core erasure pattern:
./trigger_erasure.sh "PERSON_KEY_123,PERSON_KEY_456"
├── Check process locks (IDG, PUBM)
├── Load taxonomy data (household relationships)  
├── Sequential processing of data sources:
│   ├── MatchV1 files (households_cv_master*, IP_Address_Data_Output*)
│   ├── MatchV2 files (DE_rows_to_keep.parquet, chv_mk2.parquet)
│   ├── IDGraph files (fpid_*, hems_*, ip_*, maids_*)
│   └── Taxonomy files (taxonomy.parquet)
└── Email completion status
```

### Proposed AWS Architecture

```python
# DAG-based flow representation
Airflow Trigger → EMR Initialize → Dependency Check → Parallel EMR Jobs → Cleanup → Notifications

# Core DAG structure:
data_erasure_dag.py
├── create_script_arguments (calculate paths, validate inputs)
├── initialise_emr (create EMR Serverless application)
├── check_dependencies (replace lock file mechanism)
├── Parallel Processing Groups:
│   ├── process_matchv1 (EMR job for V1 data sources)
│   ├── process_matchv2 (EMR job for V2 data sources)
│   └── process_idgraph (EMR job for ID Graph sources)
├── finalise_emr (cleanup EMR application)
└── send_notifications (email completion status)
```

## Stage-by-Stage Comparison

### 1. Process Initiation

| Aspect | On-Premises | AWS | Notes |
|--------|-------------|-----|-------|
| **Trigger** | Manual shell execution | Airflow DAG trigger with parameters | AWS: Better parameter validation and audit trail |
| **Input Format** | Command line arguments | DAG parameters via Airflow UI/API | AWS: Improved user experience and logging |
| **Validation** | Basic shell parameter checking | Comprehensive input validation in DAG | AWS: Enhanced error handling upfront |

**AWS Snippet Example:**
```python
# DAG parameter definition
with DAG(
    "data_erasure_process",
    params={
        "person_keys": Param(default="", type="string", description="Comma-separated person keys to erase"),
        "dry_run": Param(default=False, type="boolean", description="Preview mode without actual deletion")
    }
)
```

### 2. Process Control & Dependencies

| Aspect | On-Premises | AWS | Notes |
|--------|-------------|-----|-------|
| **Concurrency Control** | File-based locks (`/tmp/*.lock`) | Airflow task dependencies + DAG state checking | AWS: More robust conflict resolution |
| **Process Monitoring** | Log files + manual checking | Airflow UI + CloudWatch integration | AWS: Real-time visibility and alerting |
| **Failure Handling** | Manual intervention required | Automatic retry with exponential backoff | AWS: Self-healing capabilities |

**Lock Mechanism Evolution:**
```bash
# On-Premises: File-based locking
if [ -f $IDG_LOCK_FILE ]; then
    echo "An IDG process is already running"
    return 1
fi

# AWS: DAG-based dependency checking
def check_running_processes(**context):
    # Check for running DAGs: hems_p10_ingest, hems_p20_graph_creation, etc.
    # Return task_id for next step or failure state
```

### 3. Data Storage & Access

| Aspect | On-Premises | AWS | Notes |
|--------|-------------|-----|-------|
| **Storage Backend** | HDFS (`/user/unity/`) | S3 (`s3://unity-*-data/`) | AWS: Unlimited scalability and durability |
| **Path Resolution** | Static HDFS paths | Dynamic S3 path calculation | AWS: Environment-aware path management |
| **File Operations** | HDFS CLI commands | Boto3/Spark S3 integration | AWS: Native cloud integration |

**Path Migration Example:**
```bash
# On-Premises Paths
BASE_PATH="/user/unity"
update_file "$PERSON_KEYS" "$BASE_PATH/match2/process" "cb_key_household" "chv_mk2.parquet"

# AWS Paths (calculated dynamically in DAG)
PROTOCOL = "s3a"
interim_bucket = get_bucket_name("interim")  
data_path = f"{PROTOCOL}://{interim_bucket}/match2/process/chv_mk2.parquet"
```

### 4. Compute Execution

| Aspect | On-Premises | AWS | Notes |
|--------|-------------|-----|-------|
| **Compute Platform** | Shared YARN cluster | Isolated EMR Serverless applications | AWS: Better resource isolation and scaling |
| **Job Submission** | `spark-submit` commands | EMR job submission via Airflow | AWS: Programmatic job management |
| **Resource Management** | Manual cluster sizing | Auto-scaling based on workload | AWS: Cost optimization and performance |

**Compute Evolution:**
```bash
# On-Premises: Direct Spark submission
spark-submit --master yarn --queue unity data_erasure.py -pk $1 -rf $2 -rc $3

# AWS: EMR job via Airflow
def run_erasure_job(**context):
    job = start_emr_job(
        application_id=app_id,
        job_driver={
            "sparkSubmit": {
                "entryPoint": "s3://code-bucket/data_erasure_emr.py",
                "entryPointArguments": ["--person_keys", person_keys, "--data_sources", json.dumps(sources)]
            }
        }
    )
```

### 5. Data Processing Logic

| Aspect | On-Premises | AWS | Notes |
|--------|-------------|-----|-------|
| **Core Algorithm** | Python/Spark logic in `data_erasure.py` | **Identical logic** in `data_erasure_emr.py` | **No changes to erasure business logic** |
| **File Discovery** | HDFS file listing | S3 object listing with prefixes | AWS: Leverages S3 native capabilities |
| **Data Filtering** | Spark DataFrame operations | **Same Spark operations** | **Business logic remains unchanged** |

**Core Processing (Unchanged Logic):**
```python
# Both environments use identical erasure logic:
def process_data_sources(spark, person_keys, data_sources):
    # 1. Get households from taxonomy
    hh_to_delete = get_households_from_taxonomy(person_keys)
    
    # 2. For IDGraph: convert households to match_ids
    if idg_flag:
        ids_to_delete = get_matchids_from_lookup(hh_to_delete)
    
    # 3. Filter out records containing person data
    filtered_data = original_data.where(~F.col(target_column).isin(ids_to_delete))
```

### 6. File Operations & Persistence

| Aspect | On-Premises | AWS | Notes |
|--------|-------------|-----|-------|
| **File Replacement** | Write temp → Remove → Rename pattern | Direct S3 overwrite (atomic) | AWS: Simpler, more reliable operations |
| **Backup Strategy** | Manual temp file creation | S3 versioning + lifecycle policies | AWS: Automated backup and retention |
| **Atomicity** | Multi-step HDFS operations | Single S3 write operation | AWS: Reduced failure points |

**File Operation Evolution:**
```bash
# On-Premises: Complex multi-step process
write_file(filtered_data, temp_file_path)
remove_file_from_hdfs(original_file_path)  
rename_file_in_hdfs(temp_file_path, original_file_path)

# AWS: Simplified atomic operation  
filtered_data.write.parquet(s3_path, mode='overwrite')
```

### 7. Monitoring & Notifications

| Aspect | On-Premises | AWS | Notes |
|--------|-------------|-----|-------|
| **Process Tracking** | Log files + email summaries | Airflow UI + CloudWatch + emails | AWS: Multi-channel visibility |
| **Error Alerting** | Email on script failure | Airflow failure callbacks + SNS | AWS: Real-time incident response |
| **Audit Trail** | Local log files | CloudTrail + S3 access logs + Airflow logs | AWS: Comprehensive compliance logging |

## Migration Benefits

### Operational Improvements
- **Automated Scaling**: EMR Serverless automatically provisions compute resources
- **Enhanced Monitoring**: Real-time DAG progress visibility in Airflow UI
- **Improved Reliability**: Built-in retry mechanisms and failure notifications
- **Cost Efficiency**: Pay-per-use compute model vs. always-on cluster

### Compliance & Security
- **Audit Trail**: Comprehensive logging across all AWS services
- **Access Control**: IAM-based permissions vs. manual access management  
- **Data Encryption**: S3 encryption at rest and in transit
- **Compliance Reporting**: Automated evidence collection for audits

### Developer Experience
- **Visual Workflow**: DAG visualization vs. shell script dependencies
- **Parameter Management**: Structured input validation vs. command line parsing
- **Testing Capabilities**: Dry-run mode and isolated environments
- **Deployment Automation**: Infrastructure as Code vs. manual setup

## Implementation Phases

### Phase 1: Foundation (Weeks 1-2)
- Set up S3 bucket structure mirroring HDFS paths
- Create EMR Serverless application templates
- Establish Airflow DAG skeleton following HEMS P10 pattern

### Phase 2: Core Migration (Weeks 3-4)
- Adapt `data_erasure.py` for S3 paths (`data_erasure_emr.py`)
- Implement DAG tasks for each processing group
- Create monitoring and notification functions

### Phase 3: Testing & Validation (Weeks 5-6)
- Parallel testing on sample datasets
- Validate identical erasure outcomes
- Performance benchmarking and optimization

### Phase 4: Production Cutover (Week 7)
- Coordinated migration with data freeze window
- Switch DNS/routing to AWS infrastructure
- Post-migration validation and monitoring

## Risk Mitigation

### Technical Risks
- **Data Consistency**: Validate identical processing outcomes through comprehensive testing
- **Performance Impact**: Benchmark EMR vs. YARN performance with real datasets
- **Integration Dependencies**: Ensure compatibility with downstream systems

### Operational Risks  
- **Team Training**: Airflow and AWS service knowledge transfer
- **Process Changes**: Update operational procedures and runbooks
- **Rollback Planning**: Maintain on-premises capability during transition

## Success Metrics

### Functional Metrics
- **Processing Accuracy**: 100% identical erasure outcomes vs. on-premises
- **Data Completeness**: All data sources successfully migrated and accessible
- **Compliance Validation**: Audit trail completeness and accessibility

### Performance Metrics
- **Processing Time**: Maintain or improve current erasure processing duration
- **System Availability**: >99.9% uptime for erasure capabilities
- **Cost Efficiency**: 20% reduction in compute costs through serverless model

### Operational Metrics
- **Incident Reduction**: 50% fewer manual interventions required
- **Monitoring Effectiveness**: <5 minute detection time for process failures
- **Developer Productivity**: Improved troubleshooting and debugging capabilities

---

*This migration follows established patterns from the HEMS P10 workflow, ensuring consistency with existing AWS infrastructure while modernizing the data erasure process for improved reliability and maintainability.*