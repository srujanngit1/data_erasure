## Match Data Erasure Process

This process deletes all households associated with given person key from Match.

helper_functions.py - contains all functions that can be reused across multiple scripts
config.py - contains all configurable paths that can be used across multiple scripts
data_erasure.py - the script that loops through given folder (and file pattern if provided) and deletes households based on the given columnname for a household in that file and replaces the original files
trigger_erasure.sh - bash script which calls the data erasure spark script for required folders, requires 1 argument which is the person key

To run the process 

1. Check if all paths in trigger_erasure.sh (run_data_erasure function) are correct.
2. Ensure the bash scripts have executable permissions else run below command within the match-data-erasure directory 
    chmod +x *.sh
3. Run trigger_erasure.sh by providing the person key as argument. In case of multiple person keys, simply pass keys as comma separated values.

    ./trigger_erasure.sh 1234
    OR
    ./trigger_erasure.sh 1234,4567,89101
            'path': 'id_graph/fpid/*/*',