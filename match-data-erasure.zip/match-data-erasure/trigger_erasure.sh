#/bin/bash

source /etc/profile.d/hadoop.sh

PERSON_KEYS=$1
CURRENT_DIR=$(pwd)
LOGS_DIR="$CURRENT_DIR/logs"
BASE_PATH="/user/unity"
MAILLIST=$(python3 -c "import config; print(config.MAILLIST)")
PUBM_LOCK_FILE="/tmp/process_flow.lock"
IDG_LOCK_FILE="/tmp/idg_process_flow.lock"


# Sends mail notification to recipients
send_mail(){
    duration=$1
    readable_duration=$(date -u -d @${duration} +"%T")
    subject="Match Data Erasure Process"
    body="Ran Data Erasure process, took $readable_duration to complete"
    python3 -c "from helper_functions import send_email; send_email('$MAILLIST','$subject','$body')" && echo "Sent storage stats mail"
}


# Check if idgraph flow or pubmatic process is running currently
can_data_erasure_process_run(){
    if [ -f $IDG_LOCK_FILE ]
    then
        echo "An IDG process is already running"
        return 1
    elif [ -f $PUBM_LOCK_FILE ]
    then
        echo "Pubmatic process hasn't finished yet"
        return 1
    else
        return 0
    fi
}


# Filters out records containing given person key in the given file/folder
# Arguments: 1. person_key, 2. file/folder path, 3. column containing household key in the file, 4. file name pattern, 5. flag for id_graph files (optional, as they have match_id)
update_file(){
    printf '#%.0s' {1..10}; echo
    if [ $# -eq 5 ]
    then
        echo "running updation of idgraph files with file pattern"
        spark-submit --master yarn --queue unity data_erasure.py -pk $1 -rf $2 -rc $3 -fp $4 -igf
    else    
        echo "running updation with file pattern"
        spark-submit --master yarn --queue unity data_erasure.py -pk $1 -rf $2 -rc $3 -fp $4
    fi
}


#Process starts here
run_data_erasure() {
    if can_data_erasure_process_run
    then        
        printf '#%.0s' {1..100}; echo                
        starttime=$(date +%s)
        echo "Started Data Erasure Process"
        # Started process
        # update_file "$BASE_PATH/testing" "hhkey" "dataerasure"
        # MatchV1
        update_file "$PERSON_KEYS" "$BASE_PATH/v1/monthly_cv" "cb_key_household" "IP_Address_Data_Output*"
        update_file "$PERSON_KEYS" "$BASE_PATH/v1/matchboxes/central_matchbox/backlog" "cb_key_household" "households_cv_master*"
        update_file "$PERSON_KEYS" "$BASE_PATH/v1/matchboxes/central_matchbox/backlog" "match_key" "household.csv"
        update_file "$PERSON_KEYS" "$BASE_PATH/v1/matchboxes/central_matchbox/backlog" "cb_key_household" "households_with_optouts.parquet"
        update_file "$PERSON_KEYS" "$BASE_PATH/v1/matchboxes/central_matchbox/backlog" "cb_key_household" "households_without_optouts.parquet"
        update_file "$PERSON_KEYS" "$BASE_PATH/v1/matchboxes/central_matchbox/backlog" "match_key" "ip_date_household.csv"
        # MatchV2
        update_file "$PERSON_KEYS" "$BASE_PATH/match2/process" "cb_key_household" "DE_rows_to_keep.parquet"
        update_file "$PERSON_KEYS" "$BASE_PATH/match2/process" "cb_key_household" "chv_mk2.parquet"
        update_file "$PERSON_KEYS" "$BASE_PATH/match2/process" "household" "id5.parquet"
        update_file "$PERSON_KEYS" "$BASE_PATH/match2/process" "household" "id5_maids.parquet"
        update_file "$PERSON_KEYS" "$BASE_PATH/match2/process" "cb_key_household" "chv_mk2_180.parquet"
        update_file "$PERSON_KEYS" "$BASE_PATH/match2/process" "cb_key_household" "chv_mk2_180_dd.parquet"
        update_file "$PERSON_KEYS" "$BASE_PATH/match2/process" "cb_key_household" "hh_all.parquet"
        update_file "$PERSON_KEYS" "$BASE_PATH/match2/process" "cb_key_household" "taxonomy_suppress.parquet"
        update_file "$PERSON_KEYS" "$BASE_PATH/match2/process" "cb_key_household" "uid_hh.parquet"
        update_file "$PERSON_KEYS" "$BASE_PATH/match2/process" "cb_key_household" "uid_hh_dd.parquet"
        update_file "$PERSON_KEYS" "$BASE_PATH/match2/process" "cb_key_household" "uid_hh_pp_s_code.parquet"
        update_file "$PERSON_KEYS" "$BASE_PATH/match2/unacast" "cb_key_household" "unacast_hh_ip_flags.parquet"
        # IDGraph
        update_file "$PERSON_KEYS" "$BASE_PATH/id_graph/graphs/fpid" "match_id" "fpid_*" "idgraph"
        update_file "$PERSON_KEYS" "$BASE_PATH/id_graph/graphs/hems" "match_id" "hems_*" "idgraph"
        update_file "$PERSON_KEYS" "$BASE_PATH/id_graph/graphs/ip" "match_id" "ip_*" "idgraph"
        update_file "$PERSON_KEYS" "$BASE_PATH/id_graph/graphs/maids" "match_id" "maids_*" "idgraph"
        update_file "$PERSON_KEYS" "$BASE_PATH/id_graph/graphs/mobile" "match_id" "mobile_*" "idgraph"
        update_file "$PERSON_KEYS" "$BASE_PATH/id_graph/graphs/pc" "match_id" "pc_*" "idgraph"
        update_file "$PERSON_KEYS" "$BASE_PATH/id_graph/graphs/uid" "match_id" "uid_*" "idgraph"
        # Taxonomy
        update_file "$PERSON_KEYS" "$BASE_PATH/match2/taxonomy" "cb_key_household" "taxonomy.parquet"      
        # Finished process
        endtime=$(date +%s)
        duration=$(($endtime - $starttime))
        echo "Finished Data Erasure, took $duration seconds to complete"
        send_mail $duration
    else
        echo "A new process can't be run before match or idgraph process has finished"
    fi
}

run_data_erasure >> "$LOGS_DIR/data_erasure.log"