import logging
import logging.handlers
import pyspark.sql.functions as F
import os
import time
import sys

from config import LOGPATH,MASK,PARENT_PATH,MAILLIST,IDG_LOOKUP_PATH
from helper_functions import dolog, get_latest_hdfs_file,read_file,write_file,list_files_in_hdfs,remove_file_from_hdfs,rename_file_in_hdfs,send_email,get_households_data


def logic_main(ctx, logger, mask, parent_path, person_keys, req_folder, req_col, file_pattern, maillist, idg_lookup, idg_flag):
   try:
      logger.info(f"running process for person key {person_keys} on {mask} inside folder: {req_folder} for file pattern: {file_pattern}")

      latest_tax_file = get_latest_hdfs_file(parent_path, "taxonomy.parquet")
      logger.info("latest taxonomy file: " + latest_tax_file)

      latest_tax_data = read_file(ctx, logger, latest_tax_file)
      logger.info("read latest taxonomy data")

      if not latest_tax_data:
         logger.error("no taxonomy file found, exiting process")
         raise

      person_to_hh_log, hh_to_delete = get_households_data(latest_tax_data, person_keys) 
      logger.info(f"found data: {person_to_hh_log} for {person_keys}, all households to delete: {hh_to_delete}")

      if not hh_to_delete:
         logger.info(f"no households found for {person_keys} in taxonomy")
         return

      hhs = hh_to_delete #setting hhs to default value

      if idg_flag:
         latest_lookup_file = get_latest_hdfs_file(idg_lookup, "match_id_lookup")
         logger.info("latest idg lookup file: " + latest_lookup_file)
         latest_lookup_data = read_file(ctx, logger, latest_lookup_file)
         logger.info("read latest idg lookup data")
         if not latest_lookup_data:
            logger.error("no idg lookup file found, exiting process")
            sys.exit(1)
         matchids_to_delete = list(set([
            row["match_id"] for row in 
            latest_lookup_data.where(F.col("cb_key_household").isin(hh_to_delete)).collect()
         ]))      
         hhs = matchids_to_delete

      
      all_files = list_files_in_hdfs(req_folder, file_pattern)
      logger.info(f"found {len(all_files)} in {req_folder}")
      
      if all_files:
         for file_path in all_files:
            filedata = read_file(ctx, logger, file_path)
            logger.info(f"read {file_path}")

            if filedata:
               initial_count = filedata.count()
               logger.info(f"initial count of households in file: {initial_count}")                               
               
               records_to_delete = filedata.where(F.col(req_col).isin(hhs)).count()
               logger.info(f"found {records_to_delete} to delete in {file_path}")

               if records_to_delete == 0:
                  logger.info(f"no records found to delete in {file_path}")
               else:
                  filedata_filtered = filedata.where(~F.col(req_col).isin(hhs))
                  logger.info(f"tried to filter out {os.path.basename(file_path)} for matchids belonging to {person_keys}")

                  final_count = filedata_filtered.count()
                  logger.info(f"filtered count of households in file: {final_count}")

                  delcount = initial_count - final_count
                  logger.info(f"deleting {delcount} records in {file_path}")

                  temp_file_path = f"{os.path.dirname(file_path)}/bkp_{os.path.basename(file_path)}"
                  try:
                     write_file(logger, filedata_filtered, temp_file_path)
                     logger.info(f"wrote filtered data to {temp_file_path}")
                  except:
                     send_email(maillist, "Temp Write Issue", f"unable to write out {temp_file_path}")
                     logger.exception("unable to write filtered data to {temp_file_path}")                     
                  else:                  
                     time.sleep(10)
                     logger.info("adding delay to allow time to write")
                     try:
                        if remove_file_from_hdfs(file_path):
                           logger.info("removed original file")
                           if rename_file_in_hdfs(temp_file_path,file_path):
                              logger.info(f"renamed {temp_file_path} back to its original name {file_path}")
                           else:
                              send_email(maillist, "Rename Issue", f"unable to replace {file_path}")
                              logger.info("unable to replace original file")                     
                        else:
                           send_email(maillist, "Removal Issue", f"unable to remove {file_path}")
                           logger.info("unable to remove original file")
                     except:
                        send_email(maillist, "Replace Issue", f"unable to replace {file_path}")
                        logger.exception("error replacing files")
            else:               
               logger.error(f"unable to read {file_path}")
      else:
         logger.info(f"no files found in {req_folder}")
   except Exception as e:
      logger.exception(f"process failed: {e}")
      send_email(maillist, "Process Failed", f"process failed for {person_keys} on {mask}")
               
         
if __name__=="__main__":
   from pyspark.sql import SparkSession   
   import argparse

   parser = argparse.ArgumentParser()
   parser.add_argument(
      "-m", "--mask", type=str, help="date when process is run", default=MASK
   )   
   parser.add_argument(
      "-pp", "--parent_path", type=str, help="path which contains the household to person key relationship", default=PARENT_PATH
   )
   parser.add_argument(
      "-pk", "--person_keys", type=str, help="comma separated key(s) for the person to delete"
   )   
   parser.add_argument(
      "-rf", "--req_folder", type=str, help="folder where required files exist"
   )
   parser.add_argument(
      "-rc", "--req_col", type=str, help="column name for households in the given file"
   )
   parser.add_argument(
      "-fp", "--file_pattern", type=str, help="file pattern to search for in the given folder"
   )
   parser.add_argument(
      "-ml", "--maillist", type=str, help="recipients of email alerts", default=MAILLIST
   )
   parser.add_argument(
      "-igl", "--idg_lookup", type=str, help="path which contains matchid to cbkey relationship", default=IDG_LOOKUP_PATH
   )
   parser.add_argument(
      "-igf", "--idg_flag", action='store_true', help="flag to denote if the process is running for idgraph files"
   )
   

   args = parser.parse_args()

   # initialize logger
   logger = dolog(logging.getLogger("dataerasure.py"), f"{LOGPATH}/match_data_erasure__{MASK}.log")

   # initialize spark
   spark = SparkSession.builder.appName('data_erasure').getOrCreate()

   logic_main(
      spark, logger, args.mask, args.parent_path, args.person_keys, args.req_folder, args.req_col, 
      args.file_pattern, args.maillist, args.idg_lookup, args.idg_flag
   )