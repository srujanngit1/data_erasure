import logging
import logging.handlers
from datetime import datetime
from pathlib import Path
import os

script_dir = str(Path(os.path.dirname(__file__)).resolve())

MASK = datetime.now().date() #default date is today
PARENT_PATH = "match2/taxonomy/*/process"
IDG_LOOKUP_PATH = "id_graph/lookup/experian"
TEMP_FOLDER = "match2/temp"
LOGPATH = f"{script_dir}/logs" #default path for logs
MAILLIST="emsactivatealerts@experian.com"