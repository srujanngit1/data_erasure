"""
DAG to process HEMS data ingestion (P10).
Ingests email data, cleans it, and creates SHA256 hashes.
"""

import json
import logging
import time
from datetime import datetime, timedelta

from airflow import DAG
from airflow.models.param import Param
from airflow.operators.python import PythonOperator, BranchPythonOperator, get_current_context
from airflow.operators.dummy import DummyOperator
from airflow.operators.email import EmailOperator
from airflow.models import Variable
from airflow.operators.trigger_dagrun import TriggerDagRunOperator

import pendulum
import re
import sys
import os
import tempfile
from pathlib import Path

# Set up paths
sys.path.append(str(Path(__file__).resolve().parents[1]))
sys.path.append(str(Path(__file__).resolve().parents[1]) + "/shared")

# Standard logging configuration
logging.getLogger(__name__).setLevel(logging.INFO)

# Import shared functions
import shared.functions
import shared.utils
import shared.utils.utils
import shared.bucket_list

logging.info(f"sys.path {sys.path}")

from shared.functions import platform, get_env, parse_s3_path

logging.info(f"Platform is {platform}")

# Import EMR application factory utilities
from shared.utils.emr_application_factory import create_emr_application, delete_emr_application, start_emr_job
import boto3

# Define DAG with parameters
with DAG(
    "hems_p10_ingest",
    description="Process HEMS data ingestion (P10)",
    catchup=False,
    start_date=pendulum.datetime(2023, 1, 1, tz="UTC"),
    schedule_interval="0 9 * * 1",  # Every Monday at 9 AM
    tags=["hems", "ingestion"],
    default_args={
        'owner': 'airflow',
        'depends_on_past': False,
        'email_on_failure': True,
        'email_on_retry': False,
        'retries': 1,
        'retry_delay': timedelta(minutes=5),
    },
) as dag:

    def create_script_arguments(**context):
        """
        Calculate all paths and configuration needed for the workflow
        
        Args:
            context: Airflow task context
            
        Returns:
            None
        """
        from shared.bucket_list import get_bucket_name
        from shared.functions import latest_path, get_env, latest_file, file_exists
        
        logging.info("Creating script arguments")
        
        # Initialize workflow timing
        workflow_start_time = time.time()
        logging.info("Workflow started %s", datetime.fromtimestamp(workflow_start_time))
        
        # Get environment
        env = get_env()
        
        # Store workflow timing info
        context["task_instance"].xcom_push(key="workflow_start_time", value=workflow_start_time)
        context["task_instance"].xcom_push(key="env", value=env)
        
        # Use execution date directly (no run_date parameter)
        execution_date = context["execution_date"]
        
        # Calculate month (YYYYMM) format for file paths
        month = execution_date.strftime("%Y%m")
        date_str = execution_date.strftime("%Y-%m-%d")
        now_str = datetime.now().strftime("%Y%m%d%H%M%S")
        
        # Store dates
        context["task_instance"].xcom_push(key="month", value=month)
        context["task_instance"].xcom_push(key="execution_date", value=date_str)
        
        # Define protocol
        PROTOCOL = "s3a"
        
        # Get bucket names
        source_bucket = get_bucket_name("source")
        interim_bucket = get_bucket_name("interim")
        output_bucket = get_bucket_name("output")
        code_bucket = get_bucket_name("code")
        log_bucket = get_bucket_name("logs")
        stats_bucket = get_bucket_name("stats")
        
        # Store timestamp for stats
        stats_timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
        context["task_instance"].xcom_push(key="stats_timestamp", value=stats_timestamp)
        
        # Store bucket names
        context["task_instance"].xcom_push(key="source_bucket", value=source_bucket)
        context["task_instance"].xcom_push(key="interim_bucket", value=interim_bucket)
        context["task_instance"].xcom_push(key="output_bucket", value=output_bucket)
        context["task_instance"].xcom_push(key="code_bucket", value=code_bucket)
        context["task_instance"].xcom_push(key="log_bucket", value=log_bucket)
        context["task_instance"].xcom_push(key="stats_bucket", value=stats_bucket)
        
        # Find latest input file
        year_month = execution_date.strftime("%Y-%m")
        try:
            input_file = latest_path(
                source_bucket, "internal/hems/", f"f15_email_", False
            )
        except Exception as e:
            logging.warning(f"Error finding latest input file: {e}")
            input_file = f"{PROTOCOL}://{source_bucket}/internal/hems/{year_month}/input/f15_email_{month}.csv"
        
        # Try to find previous stats - keep original pattern
        try:
            previous_stats = latest_path(stats_bucket, "quick_stats/ID010/stats_")
        except Exception as e:
            logging.warning(f"Error finding previous stats: {e}")
            previous_stats = None
        
        # Define paths
        hems_ingest_filepaths = {
        "input": input_file,
        "output_temp": f"{PROTOCOL}://{interim_bucket}/idgraph/hems/{date_str}/process/temp.parquet",
        "output_f15": f"{PROTOCOL}://{interim_bucket}/idgraph/hems/{date_str}/process/f15.parquet",
        "output_hashed": f"{PROTOCOL}://{interim_bucket}/hems/{date_str}/process/f15_sha256.parquet",
        "prev_stats": previous_stats,
        "stats": f"{PROTOCOL}://{stats_bucket}/quick_stats/ID010/stats_{now_str}.txt",
    "formatted_stats": f"{PROTOCOL}://{stats_bucket}/quick_stats/ID010/formatted_stats_{now_str}.txt",
    }
        
        logging.info(f"Using HEMS ingest filepaths {hems_ingest_filepaths}")
        
        # Store all paths
        context["task_instance"].xcom_push(key="HEMS_INGEST_FILEPATHS", value=hems_ingest_filepaths)
        
        # Check if input file exists
        try:
            input_path = hems_ingest_filepaths["input"]
            logging.info(f"Original input path: {input_path}")
            
            # Use parse_s3_path function instead of manual string parsing
            bucket_name, key = parse_s3_path(input_path)
            
            logging.info(f"Checking file exists in bucket: {bucket_name} with key: {key}")
            
            if file_exists(bucket_name, key, is_pattern_parent_directory_name=False):
                context["task_instance"].xcom_push(key="input_exists", value=True)
                logging.info(f"Input file found at {input_path}")
            else:
                context["task_instance"].xcom_push(key="input_exists", value=False)
                logging.warning(f"Input file not found at {input_path}")
                
        except Exception as e:
            context["task_instance"].xcom_push(key="error_message", value=str(e))
            logging.error(f"Error checking input file: {str(e)}")
            raise e
        
        # Push EMR common configuration
        execution_role_arn = shared.utils.utils.get_emr_serverless_role(env)
        log_uri_prefix = f"s3://{log_bucket}/spark-logs"
        shared_code = [
            f"s3://{code_bucket}/zipped/ems-code-shared.zip",
            f"s3://{code_bucket}/zipped/ems-code-id-graph.zip",
        ]
        hems_code_prefix = f"s3://{code_bucket}/repos/ems-code-id-graph/spark/hems"
        
        # Push common args
        context["task_instance"].xcom_push(key="EXECUTION_ROLE_ARN", value=execution_role_arn)
        context["task_instance"].xcom_push(key="LOG_URI_PREFIX", value=log_uri_prefix)
        context["task_instance"].xcom_push(key="SHARED_CODE", value=shared_code)
        context["task_instance"].xcom_push(key="HEMS_CODE_PREFIX", value=hems_code_prefix)
        
        return True

    def initialise(**context):
        """
        Initialize EMR Serverless application
        
        Args:
            context: Airflow task context
            
        Returns:
            String indicating success
        """
        logging.info("Initializing EMR Serverless application")
        
        # Get EMR subnets and security groups
        emr_subnet_ids = None
        emr_security_group_ids = None
        
        # Create application name with timestamp
        date = datetime.now().strftime("%Y%m%d%H%M%S")
        emr_application_name = f"hems-p10-{date}"
        
        logging.info(f"Creating EMR application with name {emr_application_name}, subnets {emr_subnet_ids}, security groups {emr_security_group_ids}")
        
        # Create EMR application
        app_id = create_emr_application(
            context, emr_application_name, emr_subnet_ids, emr_security_group_ids
        )
        
        # Store in XCom
        context["task_instance"].xcom_push(key="application_id", value=app_id)
        context["task_instance"].xcom_push(key="emr_application_name", value=emr_application_name)
        
        logging.info(f"Created EMR application {app_id}")
        
        end_time = time.time()
        workflow_start_time = context["task_instance"].xcom_pull(key="workflow_start_time", task_ids="create_script_arguments")
        
        logging.info(f"Initialisation finished, created {app_id}, time taken: {timedelta(seconds=end_time - workflow_start_time)}")
        
        return "Executed initialise..."

    def check_input_exists(**context):
        """
        Check if the input file exists in S3
        
        Args:
            context: Airflow task context
            
        Returns:
            Task ID of the next task to execute
        """
        input_exists = context["ti"].xcom_pull(key="input_exists", task_ids="create_script_arguments")
        
        if input_exists:
            logging.info("Input file exists, proceeding with processing")
            return "collect_stats"
        else:
            logging.warning("Input file does not exist, skipping processing")
            return "input_missing"

    def run_p10_processing(**context):
        """
        Execute the HEMS P10 ingest processing task
        
        Args:
            context: Airflow task context
            
        Returns:
            Message indicating completion
        """
        from shared.utils.emr_application_factory import start_emr_job
        
        start_time = time.time()
        
        app_id = context["task_instance"].xcom_pull(key="application_id", task_ids="initialise")
        
        EXECUTION_ROLE_ARN = context["task_instance"].xcom_pull(
            key="EXECUTION_ROLE_ARN", task_ids="create_script_arguments"
        )
        LOG_URI_PREFIX = context["task_instance"].xcom_pull(
            key="LOG_URI_PREFIX", task_ids="create_script_arguments"
        )
        SHARED_CODE = context["task_instance"].xcom_pull(
            key="SHARED_CODE", task_ids="create_script_arguments"
        )
        HEMS_CODE_PREFIX = context["task_instance"].xcom_pull(
            key="HEMS_CODE_PREFIX", task_ids="create_script_arguments"
        )
        
        # Get paths from HEMS_INGEST_FILEPATHS
        hems_ingest_filepaths = context["task_instance"].xcom_pull(
            key="HEMS_INGEST_FILEPATHS", task_ids="create_script_arguments"
        )
        month = context["task_instance"].xcom_pull(key="month", task_ids="create_script_arguments")
        
        # Extract individual paths from the dictionary
        input_path = hems_ingest_filepaths["input"]
        temp_output_path = hems_ingest_filepaths["output_temp"]
        final_output_path = hems_ingest_filepaths["output_f15"]
        sha256_output_path = hems_ingest_filepaths["output_hashed"]
        prev_stats_path = hems_ingest_filepaths["prev_stats"]
        current_stats_path = hems_ingest_filepaths["stats"]
        formatted_stats_path = hems_ingest_filepaths["formatted_stats"]
        
        # Set up job arguments with handling for None values
        job_args = [
            "--input_path", input_path,
            "--temp_output_path", temp_output_path,
            "--final_output_path", final_output_path,
            "--sha256_output_path", sha256_output_path,
            "--month", month
        ]

        # Add prev_stats_path only if it exists
        if prev_stats_path:
            job_args.extend(["--prev_stats_path", prev_stats_path])
        else:
            logging.info("No previous stats path available")

        # Always add current_stats_path and formatted_stats_path
        job_args.extend(["--current_stats_path", current_stats_path])
        job_args.extend(["--formatted_stats_path", formatted_stats_path])
            
        main = f"{HEMS_CODE_PREFIX}/process/idg_hems_p10_ingest_emr.py"
        
        # Set the parameters for the EMR job with individual arguments
        job = start_emr_job(
            task_id="run_p10_processing",
            application_id=app_id,
            execution_role_arn=EXECUTION_ROLE_ARN,
            job_driver={
                "sparkSubmit": {
                    "entryPoint": main,
                    "entryPointArguments": job_args,
                    "sparkSubmitParameters": f"--conf spark.submit.pyFiles={','.join(SHARED_CODE) if isinstance(SHARED_CODE, list) else SHARED_CODE}",
                },
            },
            configuration_overrides={
                "monitoringConfiguration": {
                    "s3MonitoringConfiguration": {
                        "logUri": f"{LOG_URI_PREFIX}/idg_hems_p10_ingest_emr",
                    },
                }
            },
        )
        
        job_id = job.execute(get_current_context())
        
        end_time = time.time()
        logging.info(f"Process finished, time taken: {timedelta(seconds=end_time - start_time)}")
        
        return f"Executed HEMS P10 processing: {job_id}"

    def finalise(**context):
        """
        Delete EMR Serverless application and log workflow completion
        
        Args:
            context: Airflow task context
            
        Returns:
            Message indicating completion
        """
        logging.info("Finalizing EMR application")
        
        app_id = context["task_instance"].xcom_pull(key="application_id", task_ids="initialise")
        emr_application_name = context["task_instance"].xcom_pull(key="emr_application_name", task_ids="initialise")
        workflow_start_time = context["task_instance"].xcom_pull(key="workflow_start_time", task_ids="create_script_arguments")
        
        logging.info(f"Finalization started, deleting application {app_id}")
        
        # Delete EMR application
        delete_emr_application(context, emr_application_name, app_id)
        
        end_time = time.time()
        logging.info(f"Workflow finished, time taken: {timedelta(seconds=end_time - workflow_start_time)}")
        
        return "Finalized EMR application"

    def collect_stats(**context):
        """
        Collect statistics from the input file - equivalent to get_stats.py in on-prem
        
        Args:
            context: Airflow task context
            
        Returns:
            Message indicating completion
        """
        from shared.utils.emr_application_factory import start_emr_job
        
        start_time = time.time()
        
        app_id = context["task_instance"].xcom_pull(key="application_id", task_ids="initialise")
        
        EXECUTION_ROLE_ARN = context["task_instance"].xcom_pull(
            key="EXECUTION_ROLE_ARN", task_ids="create_script_arguments"
        )
        LOG_URI_PREFIX = context["task_instance"].xcom_pull(
            key="LOG_URI_PREFIX", task_ids="create_script_arguments"
        )
        SHARED_CODE = context["task_instance"].xcom_pull(
            key="SHARED_CODE", task_ids="create_script_arguments"
        )
        HEMS_CODE_PREFIX = context["task_instance"].xcom_pull(
            key="HEMS_CODE_PREFIX", task_ids="create_script_arguments"
        )
        
        # Get paths from HEMS_INGEST_FILEPATHS
        hems_ingest_filepaths = context["task_instance"].xcom_pull(
            key="HEMS_INGEST_FILEPATHS", task_ids="create_script_arguments"
        )
        
        # Get the input file path - ensure it uses s3:// protocol for get_stats_emr.py
        input_file_path = hems_ingest_filepaths["input"]
        if input_file_path.startswith("s3a://"):
            input_file_path = input_file_path.replace("s3a://", "s3://")
        
        # Get the execution date and stats bucket
        execution_date = context["task_instance"].xcom_pull(key="execution_date", task_ids="create_script_arguments")
        stats_bucket = context["task_instance"].xcom_pull(key="stats_bucket", task_ids="create_script_arguments")
        
        # Create full stats path based on environment
        stats_path = f"s3://{stats_bucket}/get_stats"
        
        # Path to the stats script
        stats_script = f"{HEMS_CODE_PREFIX}/process/get_stats_emr.py"
        
        logging.info(f"Collecting stats for HEMS input file: {input_file_path}")
        logging.info(f"Using stats path: {stats_path}")
        
        # Run the stats collection EMR job
        job = start_emr_job(
            task_id="collect_stats",
            application_id=app_id,
            execution_role_arn=EXECUTION_ROLE_ARN,
            job_driver={
                "sparkSubmit": {
                    "entryPoint": stats_script,
                    "entryPointArguments": [
                        "-m", execution_date,
                        "-if", input_file_path,
                        "-sp", stats_path
                    ],
                    "sparkSubmitParameters": f"--conf spark.submit.pyFiles={','.join(SHARED_CODE) if isinstance(SHARED_CODE, list) else SHARED_CODE}",
                }
            },
            configuration_overrides={
                "monitoringConfiguration": {
                    "s3MonitoringConfiguration": {
                        "logUri": f"{LOG_URI_PREFIX}/hems_stats",
                    }
                }
            },
        )
        
        job_id = job.execute(get_current_context())
        
        end_time = time.time()
        logging.info(f"Stats collection finished, time taken: {timedelta(seconds=end_time - start_time)}")
        
        return f"Executed stats collection: {job_id}"
    
    def send_stats_email(**context):
        """
        Sends stats email - first tries to use JSON data, falls back to CSV attachment
        
        Args:
            context: Airflow task context
            
        Returns:
            Message indicating completion
        """
        import boto3
        import tempfile
        import os

        # Get stats bucket from context instead of hardcoding
        stats_bucket = context["task_instance"].xcom_pull(key="stats_bucket", task_ids="create_script_arguments")
        
        # Current date in the required format
        current_date = datetime.now()
        mask = current_date.strftime("%Y-%m-%d")
        
        # Calculate week start date
        week_start_date = (current_date - timedelta(days=current_date.weekday())).strftime("%Y-%m-%d")
        if current_date.weekday() == 0:
            week_start_date = mask
        
        logging.info(f"Sending stats email for date: {mask}, week start: {week_start_date}")
        
        # Set recipients
        recipients = ['emsactivatealerts@experian.com']
        
        try:
            # Initialize S3 client
            s3 = boto3.client('s3')
            
            # Check for alerts first
            alert_data_path = f"get_stats/{week_start_date}/alert_data_{mask}.json"
            try:
                alert_response = s3.get_object(Bucket=stats_bucket, Key=alert_data_path)
                alert_data = json.loads(alert_response['Body'].read().decode('utf-8'))
                
                # Send alert email
                alert_subject = alert_data.get('subject', f"Alert for {mask}")
                alert_message = alert_data.get('alert_message', "An alert was triggered processing")
                
                alert_email = EmailOperator(
                    task_id="send_alert_email",
                    to=recipients,
                    subject=alert_subject,
                    html_content=f"""
                    <h2>Processing Alert</h2>
                    <p><strong>Date:</strong> {mask}</p>
                    <p><strong>Alert:</strong> {alert_message}</p>
                    <p>Please check the logs for more details.</p>

                    """,
                    dag=dag
                )
                
                alert_email.execute(context=context)
                logging.info(f"Sent alert email for {mask}")
                
            except Exception as alert_err:
                logging.info(f"No alerts found or error reading alert data: {str(alert_err)}")
            
            # FIRST TRY: Look for email JSON data
            email_data_path = f"get_stats/{week_start_date}/email_data_weekly_{week_start_date}.json"
            try:
                logging.info(f"Looking for email JSON data at {email_data_path}")
                email_response = s3.get_object(Bucket=stats_bucket, Key=email_data_path)
                email_data = json.loads(email_response['Body'].read().decode('utf-8'))
                
                # Send stats email
                email_subject = email_data.get('subject', f"Statistics for {mask}")
                email_content = email_data.get('html_content', f"<p>No detailed statistics available for {mask}</p>")
                
                stats_email = EmailOperator(
                    task_id="send_stats_email_json",
                    to=recipients,
                    subject=email_subject,
                    html_content=email_content,
                    dag=dag
                )
                
                stats_email.execute(context=context)
                logging.info(f"Sent stats email using email_data JSON")
                
                return f"Sent stats email for {mask} using JSON data"
                
            except Exception as json_err:
                logging.warning(f"No email data JSON found, trying CSV file: {str(json_err)}")
                
                # SECOND TRY: If JSON not found, try CSV file
                stats_file_key = f"get_stats/{week_start_date}/pipeline_stats__{week_start_date}.csv"
                try:
                    logging.info(f"Looking for CSV file at {stats_file_key}")
                    with tempfile.NamedTemporaryFile(delete=False, suffix='.csv') as temp_file:
                        s3.download_fileobj(stats_bucket, stats_file_key, temp_file)
                        temp_file_path = temp_file.name
                    
                    # Send the email using Airflow's EmailOperator
                    email_op = EmailOperator(
                        task_id="send_stats_email_with_attachment",
                        to=recipients,
                        subject=f"Statistics Report for {mask}",
                        html_content=f"""
                        <h2>Statistics Report for {mask}</h2>
                        <p>Please find attached the statistics report for the processing.</p>
                        <p>This is an automated message from the Airflow system.</p>
                        """,
                        files=[temp_file_path],
                        dag=dag
                    )
                    
                    email_op.execute(context=context)
                    
                    # Clean up the temporary file
                    os.unlink(temp_file_path)
                    
                    logging.info(f"Sent stats email with CSV attachment for {mask}")
                    return f"Sent stats email with CSV attachment for {mask}"
                    
                except Exception as csv_err:
                    logging.warning(f"Error with CSV file: {str(csv_err)}")
                    
                    # LAST RESORT: If both JSON and CSV fail, send a basic email
                    basic_email = EmailOperator(
                        task_id="send_basic_email",
                        to=recipients,
                        subject=f"Statistics Summary - {mask}",
                        html_content=f"""
                        <h2>Statistics Summary</h2>
                        <p>Statistics were collected for {mask} but a detailed report is not available.</p>
                        <p>This is an automated message from the processing system.</p>
                        """,
                        dag=dag
                    )
                    
                    basic_email.execute(context=context)
                    logging.info(f"Sent basic stats email for {mask}")
                    
                    return f"Sent basic stats email for {mask}"
                    
        except Exception as e:
            logging.error(f"Error sending stats email: {str(e)}")
            return f"Error sending stats email: {str(e)}"

    def send_quick_stats_email(**context):
        """
        Sends a quick stats email using the formatted report file
        Reads the content of the formatted stats text file, formats it as HTML, and sends via email
        
        Args:
            context: Airflow task context
            
        Returns:
            Message indicating completion
        """
        import boto3
        import tempfile
        import os

        
        # Get current date for email subject
        current_date = datetime.now()
        mask = current_date.strftime("%Y-%m-%d")
        
        # Set recipients
        recipients = ['emsactivatealerts@experian.com']
        
        # Get paths from HEMS_INGEST_FILEPATHS
        hems_ingest_filepaths = context["task_instance"].xcom_pull(
            key="HEMS_INGEST_FILEPATHS", task_ids="create_script_arguments"
        )
        
        # Get formatted stats path if it exists, otherwise fall back to regular stats
        if "formatted_stats" in hems_ingest_filepaths:
            current_stats_path = hems_ingest_filepaths["formatted_stats"]
            logging.info(f"Using formatted stats path: {current_stats_path}")
        else:
            current_stats_path = hems_ingest_filepaths["stats"]
            logging.info(f"Formatted stats path not found, using regular stats path: {current_stats_path}")
        
        logging.info(f"Sending quick stats email using file at: {current_stats_path}")
        
        try:
            # Parse S3 path using the parse_s3_path function
            bucket_name, key = parse_s3_path(current_stats_path)
            
            # Initialize S3 client
            s3 = boto3.client('s3')
            
            # Download the file to a temporary location
            with tempfile.NamedTemporaryFile(delete=False, suffix='.txt') as temp_file:
                s3.download_fileobj(bucket_name, key, temp_file)
                temp_file_path = temp_file.name
            
            # Read the text content
            with open(temp_file_path, 'r') as file:
                text_content = file.read()
            
            # Simply wrap the entire content in a pre tag to preserve exact formatting
            html_content = f"""
            <html>
            <body>
                <h2>HEMS P10 Processing - {mask}</h2>
                <pre>{text_content}</pre>
                <p>This is an automated message from the Airflow system.</p>
            </body>
            </html>
            """
            
            # Create the email with attachment
            email_op = EmailOperator(
                task_id="send_quick_stats_email_report",
                to=recipients,
                subject=f"*** ID010: INGEST MONTHLY HEMS *** - {mask}",
                html_content=html_content,
                files=[temp_file_path],
                dag=dag
            )
            
            # Send the email
            email_op.execute(context=context)
            
            # Clean up the temporary file
            os.unlink(temp_file_path)
            
            logging.info(f"Sent quick stats email for {mask}")
            return f"Sent quick stats email for {mask}"
            
        except Exception as e:
            logging.error(f"Error sending quick stats email: {str(e)}")
            raise e
    # Define tasks
    
    # Start task
    start = DummyOperator(task_id="start")
    
    # Create script arguments
    task_create_arguments = PythonOperator(
        task_id="create_script_arguments",
        python_callable=create_script_arguments,
        trigger_rule="none_failed",
        dag=dag,
    )
    
    # Initialize EMR application
    task_initialise = PythonOperator(
        task_id="initialise",
        python_callable=initialise,
        trigger_rule="none_failed",
        dag=dag,
    )
    
    # Check if input exists
    check_input = BranchPythonOperator(
        task_id="check_input",
        python_callable=check_input_exists,
        dag=dag,
    )
    
    # Handle case where input is missing
    input_missing = DummyOperator(task_id="input_missing", dag=dag)
    
    # Collect statistics from input file
    task_collect_stats = PythonOperator(
        task_id="collect_stats",
        python_callable=collect_stats,
        trigger_rule="none_failed",
        dag=dag,
    )
    
    # Send stats email
    task_send_stats_email = PythonOperator(
        task_id="send_stats_email",
        python_callable=send_stats_email,
        trigger_rule="none_failed",
        dag=dag,
    )
    
    # Process HEMS P10
    task_run_p10_processing = PythonOperator(
        task_id="run_p10_processing",
        python_callable=run_p10_processing,
        trigger_rule="none_failed",
        dag=dag,
    )
    
    # Finalize EMR application
    task_finalise = PythonOperator(
        task_id="finalise",
        python_callable=finalise,
        trigger_rule="none_failed_min_one_success",
        dag=dag,
    )

    # Quick stats email task
    task_send_quick_stats_email = PythonOperator(
        task_id="send_quick_stats_email",
        python_callable=send_quick_stats_email,
        trigger_rule="none_failed",
        dag=dag,
    )
    
    # Add trigger for P20 DAG to ensure sequential processing
    trigger_p20_dag = TriggerDagRunOperator(
        task_id="trigger_p20_dag",
        trigger_dag_id="hems_p20_graph_creation",
        reset_dag_run=True,
        wait_for_completion=True,
        dag=dag,
    )
    
    # Define task dependencies
    # Initialize DAG execution sequence
    start >> task_create_arguments >> task_initialise >> check_input

    # Execute standard processing workflow when input file is available
    check_input >> task_collect_stats
    task_collect_stats >> task_send_stats_email
    task_send_stats_email >> task_run_p10_processing
    task_run_p10_processing >> task_send_quick_stats_email >> task_finalise

    # Trigger P20 DAG upon successful completion of P10 processing
    task_finalise >> trigger_p20_dag

    # Handle exception path when required input is not available
    check_input >> input_missing >> task_finalise