import logging
import logging.handlers
import subprocess
import re
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import smtplib
from collections import defaultdict
import pyspark.sql.functions as F
import fnmatch
import os


def dolog(logger, logpath):
    """
    Function to setup logger object
    Returns: Logger object
    """
    file_handler = logging.handlers.RotatingFileHandler(logpath, maxBytes=1028000, backupCount=5)
    formatter = logging.Formatter('%(asctime)s %(levelname)s - %(filename)s(%(funcName)s) - %(message)s','%y/%m/%d %H:%M:%S')
    file_handler.setFormatter(formatter)
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    console_handler.setLevel(logging.DEBUG)
    logger.addHandler(console_handler)
    logger.addHandler(file_handler)
    logger.setLevel(logging.DEBUG)
    return logger


def read_file(ctx, logger, file_path):
   """
   Read parquet or csv file depending on the extension deduced from the file path
   """
   try:
      if '.csv' in file_path:
        file_data = ctx.read.csv(file_path, header=True)
      else:
        file_data = ctx.read.parquet(file_path)
   except:
      logger.exception(f'Error reading {file_path}')
      return False
   else:
      if not file_data.count()==0:
         return file_data


def write_file(logger, df, file_path):
   """
   Write parquet or csv file depending on the extension deduced from the file path
   """   
   if '.csv' in file_path:
      df.write.csv(file_path, header=True, mode='overwrite')
   else:
      df.write.parquet(file_path, mode='overwrite')


def get_latest_hdfs_file(file_path, file_pattern):
   """
   Get the latest file in the hdfs directory
   """
   if file_pattern:
      cmd = f"hdfs dfs -ls {file_path} | grep {file_pattern}" + " | sort -r -k 8 | awk '{print $8}' | head -1"
   else:
      cmd = f"hdfs dfs -ls {file_path}" + " | sort -r -k 8 | awk '{print $8}' | head -1"
   latest_path = subprocess.run(cmd, shell=True, check=True, text=True, capture_output=True).stdout.strip('\n')   
   return latest_path


def list_files_in_hdfs(hdfs_folder, file_pattern):
   """
   Lists all files recursively in an hdfs folder, can also find all files matching a pattern in a folder as well
   """
   cmd = ["hdfs", "dfs", "-ls", "-R", hdfs_folder]
   proc = subprocess.run(cmd, capture_output=True, text=True)
   all_files = [line.split()[7] for line in proc.stdout.splitlines() if line and 'Picked' not in line and len(line.split()) > 7 and all(i not in line for i in ["part","SUCCESS"])]
   if file_pattern:
      return [rfile for rfile in all_files if fnmatch.fnmatch(os.path.basename(rfile), file_pattern)]
   else:
      return all_files
   

def remove_file_from_hdfs(file_path):
   """
   Removes a file from hdfs and returns false if it fails
   """
   cmd = ["hdfs", "dfs", "-rm", "-r", file_path]
   proc = subprocess.run(cmd, capture_output=True, text=True)
   if proc.returncode:
      return False
   else:
      return True
   

def rename_file_in_hdfs(orig_path,new_path):
   """
   Renames a file in hdfs
   """   
   cmd = ["hdfs", "dfs", "-mv", orig_path, new_path]
   proc = subprocess.run(cmd, capture_output=True, text=True)
   if proc.returncode:
      return False
   else:
      return True
   

def get_greeting():
   """
   Gets the greeting based on time of day
   """
   now_time = datetime.now()
   if (now_time.hour>=12) & (now_time.hour<17):
      return "Good afternoon,"
   elif (now_time.hour>=17):
      return "Good evening,"
   else:
      return "Good morning,"


def send_email(email_to, email_subject, email_body):
   """
   Sends an email to the given email addresses with a configurable subject and body
   """
   greeting = get_greeting()
   EMAIL_FROM = 'match_data_erasure@experian.com'   
   MESSAGE_BODY = f"{greeting}\n\n{email_body}.\n\nThanks and regards \nExperian Match Team"
   SMTP_SERVER = "relay.uk.experian.local"
   msg = MIMEMultipart()
   body_part = MIMEText(MESSAGE_BODY, 'plain')
   msg['Subject'] = email_subject
   msg['From'] = EMAIL_FROM
   msg['To'] = email_to
   # Add body to email
   msg.attach(body_part)
   smtp = smtplib.SMTP(SMTP_SERVER)
   smtp.sendmail(EMAIL_FROM, email_to.split(","), msg.as_string())
   smtp.quit()
  
# def get_latest_hdfs_file(file_path, mask):
#    """
#    Returns latest cv file based on date in filename and given mask
#    """
#    cmd = ["hdfs", "dfs", "-ls", file_path]
#    proc = subprocess.run(cmd, capture_output=True, text=True)
#    all_files = [line.split()[7] for line in proc.stdout.splitlines() if line and 'Picked' not in line and len(line.split()) > 7]       
#    date_pattern = re.compile("\d{4}-\d{2}-\d{2}")        
#    required_file_path = sorted(
#       all_files, 
#       key=lambda x : datetime.strptime(date_pattern.search(x).group(),"%Y-%m-%d").date() <= mask
#    )[-1]
#    return required_file_path


def get_households_data(df, person_keys):
   """
   Returns a dictionary of person keys and their corresponding households for logging and a list of all households to delete
   """
   pks = person_keys.split(",")
   hh_to_delete = defaultdict(list)
   data = df.select("cb_key_db_person", "cb_key_household").where(F.col("cb_key_db_person").isin(pks)).collect()
   for row in data:
      hh_to_delete[row["cb_key_db_person"]].append(row["cb_key_household"])
   hh_to_delete = dict(hh_to_delete)
   all_households = [household for households in hh_to_delete.values() for household in households]
   return hh_to_delete, all_households
